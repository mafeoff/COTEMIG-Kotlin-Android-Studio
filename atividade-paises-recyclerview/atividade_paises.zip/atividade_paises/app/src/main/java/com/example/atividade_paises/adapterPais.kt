package com.example.atividade_paises

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView

class Pais (
    var banda: Int,
    var nome: String,
    var curt: Boolean
)

class adapterPais(val mudar : (banda: Int, nome:String) -> Unit) : RecyclerView.Adapter<PaisHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PaisHolder {
        var view: View =LayoutInflater.from(parent.context).inflate(R.layout.lista,parent,false)
        return PaisHolder(view)
    }

    override fun getItemCount(): Int {
        return App.paises.size
    }

    override fun onBindViewHolder(holder: PaisHolder, position: Int) {
        holder.bandaPais.setImageResource(App.paises[position].banda)
        holder.nomePais.text = App.paises[position].nome
        holder.coracao.setImageResource(R.drawable.coracao1)

        if (App.paises[position].curt){
            holder.coracao.setImageResource(R.drawable.coracao2)
        } else {
            holder.coracao.setImageResource(R.drawable.coracao1)
        }

        holder.coracao.setOnClickListener{
            if (!App.paises[position].curt){
                holder.coracao.setImageResource(R.drawable.coracao2)
                App.paises[position].curt = true
            } else {
                holder.coracao.setImageResource(R.drawable.coracao1)
                App.paises[position].curt = false
            }
        }

        holder.itemView.setOnClickListener{
            mudar.invoke(App.paises[position].banda,App.paises[position].nome)
        }
    }

}