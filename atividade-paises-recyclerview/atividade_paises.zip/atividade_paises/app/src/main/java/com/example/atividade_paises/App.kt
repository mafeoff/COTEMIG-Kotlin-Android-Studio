package com.example.atividade_paises

import android.app.Application

class App: Application() {

    companion object {
        var paises: List<Pais> = listOf(
            Pais(R.drawable.brazil,"Brazil", false),
            Pais(R.drawable.argentina,"Argentina",false),
            Pais(R.drawable.unitedstates,"Estados Unidos",false),
        )

        val paisesFavoritos get() = paises.filter { it.curt }
    }
}